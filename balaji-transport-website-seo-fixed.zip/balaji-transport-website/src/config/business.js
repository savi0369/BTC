/**
 * Balaji Transport Company - Centralized Business Configuration
 * Strictly limited to verified factual information.
 */

export const BUSINESS_INFO = {
  name: {
    en: "Balaji Transport Company",
    hi: "बालाजी ट्रांसपोर्ट कंपनी"
  },
  tagline: {
    en: "All-India Goods Booking & Transportation Enquiries",
    hi: "अखिल भारतीय माल बुकिंग एवं परिवहन पूछताछ"
  },
  ceo: {
    name: "H. D. Pathak",
    role: {
      en: "Chief Executive Officer (CEO)",
      hi: "मुख्य कार्यकारी अधिकारी (सीईओ)"
    },
    experience: {
      en: "25+ Years of Experience in the Transport Industry",
      hi: "परिवहन उद्योग में 25+ वर्षों का अनुभव"
    },
    since: 2001,
    journeyText: {
      en: "H. D. Pathak has been associated with the transport industry since 2001. His professional journey includes extensive experience in branch management, transportation operations, logistics coordination, and business development.",
      hi: "एच. डी. पाठक 2001 से परिवहन उद्योग से जुड़े हुए हैं। उनकी व्यावसायिक यात्रा में शाखा प्रबंधन, परिवहन संचालन, लॉजिस्टिक्स समन्वय और व्यापार विकास का गहरा अनुभव शामिल है।"
    },
    careerHistory: [
      {
        company: "Narayan Transport Group",
        role: "Branch General Manager",
        roleHi: "शाखा महाप्रबंधक",
        period: "2001–2020",
        periodHi: "2001–2020"
      },
      {
        company: "Mehta Transport",
        role: "Branch General Manager",
        roleHi: "शाखा महाप्रबंधक",
        period: "2020–2026",
        periodHi: "2020–2026",
        note: "Previous Position",
        noteHi: "पिछला पद"
      },
      {
        company: "Balaji Transport Company",
        role: "Chief Executive Officer",
        roleHi: "मुख्य कार्यकारी अधिकारी (सीईओ)",
        period: "2020–Present",
        periodHi: "2020–वर्तमान"
      }
    ],
    managementScope: {
      en: "Throughout his career, H. D. Pathak has managed transport operations and handled business coordination involving hundreds of transport businesses. His industry experience and professional network contribute to his leadership at Balaji Transport Company.",
      hi: "अपने पूरे करियर के दौरान, एच. डी. पाठक ने परिवहन संचालन का प्रबंधन किया है और सैकड़ों परिवहन व्यवसायों से जुड़े व्यावसायिक समन्वय का कार्य संभाला है। उनका उद्योग अनुभव और पेशेवर नेटवर्क बालाजी ट्रांसपोर्ट कंपनी के नेतृत्व को सुदृढ़ आधार प्रदान करता है।"
    }
  },
  representative: {
    role: {
      en: "External Deals & Social Media",
      hi: "एक्सटर्नल डील्स एवं सोशल मीडिया"
    },
    note: {
      en: "Representative profile and verified biography will be published upon official confirmation.",
      hi: "प्रतिनिधि का नाम एवं सत्यापित विवरण आधिकारिक पुष्टि के पश्चात साझा किया जाएगा।"
    }
  },
  contact: {
    phones: [
      {
        display: "9517137669",
        raw: "9517137669",
        tel: "+919517137669",
        whatsapp: "9517137669",
        label: { en: "Primary Booking", hi: "प्राथमिक बुकिंग" }
      },
      {
        display: "7668744025",
        raw: "7668744025",
        tel: "+917668744025",
        whatsapp: "7668744025",
        label: { en: "Operations & Enquiries", hi: "संचालन एवं पूछताछ" }
      }
    ],
    email: "balajitransportservices21@gmail.com",
    address: {
      line1: "Mehdawel",
      district: "Sant Kabir Nagar",
      state: "Uttar Pradesh",
      country: "India",
      en: "Mehdawel, Sant Kabir Nagar, Uttar Pradesh, India",
      hi: "मेंहदावल, संत कबीर नगर, उत्तर प्रदेश, भारत"
    },
    googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=Mehdawel%2C+Sant+Kabir+Nagar%2C+Uttar+Pradesh%2C+India"
  },
  services: [
    {
      id: "all-india-booking",
      title: {
        en: "All-India Goods Booking",
        hi: "अखिल भारतीय माल बुकिंग"
      },
      description: {
        en: "Coordination and goods booking services connecting businesses and consignors across commercial transport hubs in India.",
        hi: "भारत भर के वाणिज्यिक परिवहन केंद्रों में व्यवसायों और माल प्रेषकों को जोड़ने वाली माल बुकिंग एवं समन्वय सेवाएं।"
      },
      icon: "Truck"
    },
    {
      id: "freight-enquiries",
      title: {
        en: "Freight & Transportation Enquiries",
        hi: "भाड़ा एवं परिवहन पूछताछ"
      },
      description: {
        en: "Direct consultation for freight estimates, route planning assistance, vehicle capacity consultation, and dispatch schedules.",
        hi: "भाड़ा अनुमान, मार्ग योजना सहायता, वाहन क्षमता परामर्श और प्रेषण समय-सारिणी के लिए सीधी पूछताछ।"
      },
      icon: "HelpCircle"
    },
    {
      id: "mumbai-bhiwandi-mehdawel",
      title: {
        en: "Mumbai/Bhiwandi to Mehdawel Route",
        hi: "मुंबई/भिवंडी से मेंहदावल मार्ग"
      },
      description: {
        en: "Dedicated booking and freight coordination for the prominent trade corridor between Mumbai/Bhiwandi (Maharashtra) and Mehdawel (Uttar Pradesh).",
        hi: "मुंबई/भिवंडी (महाराष्ट्र) और मेंहदावल (उत्तर प्रदेश) के प्रमुख व्यापारिक गलियारे के लिए विशेष बुकिंग और माल ढुलाई समन्वय।"
      },
      icon: "Route"
    }
  ],
  sampleEnquiryMessage: {
    en: "Hello Balaji Transport Company, I would like to enquire about goods booking. Please contact me with the relevant details.",
    hi: "नमस्ते बालाजी ट्रांसपोर्ट कंपनी, मैं माल बुकिंग के संबंध में पूछताछ करना चाहता हूँ। कृपया आवश्यक विवरण के साथ मुझसे संपर्क करें।"
  }
};
