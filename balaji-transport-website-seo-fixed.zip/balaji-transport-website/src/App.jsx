import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import Header from './components/Header';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Documents from './pages/Documents';
import Contact from './pages/Contact';
import NotFound from './pages/NotFound';
import './styles/global.css';
import { BUSINESS_INFO } from './config/business';

// Automatically scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}


const PAGE_SEO = {
  '/': {
    en: { title: 'Balaji Transport Company | Goods Booking in Mehdawal', description: 'Contact Balaji Transport Company in Mehdawel, Sant Kabir Nagar, Uttar Pradesh for goods booking and freight enquiries, including Bhiwandi to Mehdawel.' },
    hi: { title: 'बालाजी ट्रांसपोर्ट कंपनी | मेंहदावल में माल बुकिंग', description: 'मेंहदावल, संत कबीर नगर, उत्तर प्रदेश में माल बुकिंग और भाड़े की पूछताछ के लिए बालाजी ट्रांसपोर्ट कंपनी से संपर्क करें।' }
  },
  '/about': {
    en: { title: 'About Us | Balaji Transport Company Mehdawal', description: 'Learn about Balaji Transport Company, its transport-industry experience, leadership and goods booking services in Mehdawel, Uttar Pradesh.' },
    hi: { title: 'हमारे बारे में | बालाजी ट्रांसपोर्ट कंपनी मेंहदावल', description: 'मेंहदावल, उत्तर प्रदेश स्थित बालाजी ट्रांसपोर्ट कंपनी और उसके परिवहन अनुभव के बारे में जानें।' }
  },
  '/services': {
    en: { title: 'Goods Booking & Freight Enquiries | Balaji Transport', description: 'Explore all-India goods booking, freight enquiries and the Mumbai/Bhiwandi to Mehdawel transport corridor with Balaji Transport Company.' },
    hi: { title: 'माल बुकिंग और भाड़ा पूछताछ | बालाजी ट्रांसपोर्ट', description: 'बालाजी ट्रांसपोर्ट कंपनी से अखिल भारतीय माल बुकिंग, भाड़े की पूछताछ और मुंबई/भिवंडी से मेंहदावल मार्ग के लिए संपर्क करें।' }
  },
  '/documents': {
    en: { title: 'Company Documents | Balaji Transport Company', description: 'View available official company documents and transport information from Balaji Transport Company, Mehdawel.' },
    hi: { title: 'कंपनी दस्तावेज़ | बालाजी ट्रांसपोर्ट कंपनी', description: 'बालाजी ट्रांसपोर्ट कंपनी मेंहदावल के उपलब्ध आधिकारिक दस्तावेज़ और परिवहन जानकारी देखें।' }
  },
  '/contact': {
    en: { title: 'Contact & Booking Enquiry | Balaji Transport Mehdawal', description: 'Call or WhatsApp Balaji Transport Company for goods booking and freight enquiries in Mehdawel, Sant Kabir Nagar, Uttar Pradesh.' },
    hi: { title: 'संपर्क और बुकिंग पूछताछ | बालाजी ट्रांसपोर्ट मेंहदावल', description: 'माल बुकिंग और भाड़े की पूछताछ के लिए बालाजी ट्रांसपोर्ट कंपनी, मेंहदावल से फोन या WhatsApp पर संपर्क करें।' }
  }
};

function SEOManager() {
  const { pathname } = useLocation();
  const { language } = useLanguageForSeo();
  useEffect(() => {
    const page = PAGE_SEO[pathname] || {
      en: { title: 'Page Not Found | Balaji Transport Company', description: 'The requested page could not be found on Balaji Transport Company website.' },
      hi: { title: 'पेज नहीं मिला | बालाजी ट्रांसपोर्ट कंपनी', description: 'बालाजी ट्रांसपोर्ट कंपनी की वेबसाइट पर मांगा गया पेज नहीं मिला।' }
    };
    const meta = page[language] || page.en;
    document.title = meta.title;
    document.documentElement.lang = language === 'hi' ? 'hi' : 'en';
    const setMeta = (selector, attr, value) => {
      let element = document.head.querySelector(selector);
      if (!element) {
        element = document.createElement('meta');
        const [key, val] = selector.match(/\[(name|property)="([^"]+)"\]/).slice(1);
        element.setAttribute(key, val);
        document.head.appendChild(element);
      }
      element.setAttribute('content', value);
    };
    setMeta('meta[name="description"]', 'name', meta.description);
    setMeta('meta[property="og:title"]', 'property', meta.title);
    setMeta('meta[property="og:description"]', 'property', meta.description);
    setMeta('meta[property="og:url"]', 'property', window.location.origin + pathname);
    setMeta('meta[property="og:image"]', 'property', window.location.origin + '/images/hero-truck.jpg');
    let canonical = document.head.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', window.location.origin + pathname);
    const business = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: BUSINESS_INFO.name.en,
      url: window.location.origin,
      email: BUSINESS_INFO.contact.email,
      telephone: BUSINESS_INFO.contact.phones.map((phone) => phone.tel),
      address: {
        '@type': 'PostalAddress',
        addressLocality: 'Mehdawel',
        addressDistrict: 'Sant Kabir Nagar',
        addressRegion: 'Uttar Pradesh',
        addressCountry: 'IN'
      }
    };
    let jsonLd = document.getElementById('business-jsonld');
    if (!jsonLd) {
      jsonLd = document.createElement('script');
      jsonLd.id = 'business-jsonld';
      jsonLd.type = 'application/ld+json';
      document.head.appendChild(jsonLd);
    }
    jsonLd.textContent = JSON.stringify(business);
  }, [pathname, language]);
  return null;
}

// Separate hook wrapper lets SEO use the existing bilingual context.
function useLanguageForSeo() {
  return useLanguage();
}

export default function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <div className="app-wrapper">
          <SEOManager />
          <ScrollToTop />
          <Header />
          <main className="app-main">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/documents" element={<Documents />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
          <WhatsAppButton variant="floating" />
        </div>
      </BrowserRouter>
    </LanguageProvider>
  );
}
