import fs from 'node:fs';
import path from 'node:path';

const outDir = path.resolve('dist');
if (!fs.existsSync(outDir)) {
  console.error('dist/ not found. Run the Vite build first.');
  process.exit(1);
}
const configured = (process.env.VITE_SITE_URL || '').trim().replace(/\/+$/, '');
const productionHost = (process.env.VERCEL_PROJECT_PRODUCTION_URL || '').trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
const vercelHost = (productionHost || process.env.VERCEL_URL || '').trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
const baseUrl = configured || (vercelHost ? `https://${vercelHost}` : '');
const robots = ['User-agent: *', 'Allow: /'];
if (baseUrl) {
  const routes = ['/', '/about', '/services', '/documents', '/contact'];
  const urls = routes.map((route) => `  <url><loc>${baseUrl}${route === '/' ? '/' : route}</loc></url>`).join('\n');
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
  fs.writeFileSync(path.join(outDir, 'sitemap.xml'), sitemap);
  robots.push('', `Sitemap: ${baseUrl}/sitemap.xml`);
  console.log(`Generated sitemap for ${baseUrl}`);
} else {
  console.warn('No VITE_SITE_URL or VERCEL_URL found; sitemap was not generated. Set VITE_SITE_URL to your deployed site URL for a sitemap.');
}
fs.writeFileSync(path.join(outDir, 'robots.txt'), `${robots.join('\n')}\n`);
