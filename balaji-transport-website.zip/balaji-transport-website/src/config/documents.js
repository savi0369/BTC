/**
 * Documents Library Configuration
 * Place verified PDF files in /public/documents/
 * Only approved, authentic documents should be registered here.
 */

export const DOCUMENTS_CONFIG = [
  // To register a document, add an entry like the following:
  // {
  //   id: "company-profile-2026",
  //   title: {
  //     en: "Balaji Transport Company Profile",
  //     hi: "बालाजी ट्रांसपोर्ट कंपनी प्रोफाइल"
  //   },
  //   description: {
  //     en: "Overview of goods booking services, network route information, and contact channels.",
  //     hi: "माल बुकिंग सेवाओं, मार्ग जानकारी और संपर्क माध्यमों का विवरण।"
  //   },
  //   fileName: "balaji-company-profile.pdf",
  //   fileSize: "PDF Document",
  //   isAvailable: false, // Set to true once the verified PDF file is placed in /public/documents/
  //   uploadDate: "2026"
  // }
];
