/**
 * Form Validation Utilities
 * Validates inputs client-side before any processing.
 */

export function validateContactForm(formData, lang = 'en') {
  const errors = {};

  // Name validation
  if (!formData.name || formData.name.trim().length < 2) {
    errors.name = lang === 'hi' 
      ? "कृपया अपना पूरा नाम या फर्म का नाम दर्ज करें।" 
      : "Please enter your full name or company name.";
  }

  // Phone validation (10 digit Indian number)
  const phoneClean = (formData.phone || "").replace(/[^0-9]/g, "");
  if (!phoneClean || phoneClean.length !== 10 || !/^[6-9]\d{9}$/.test(phoneClean)) {
    errors.phone = lang === 'hi' 
      ? "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें।" 
      : "Please enter a valid 10-digit Indian mobile number.";
  }

  // Enquiry type validation
  if (!formData.enquiryType || formData.enquiryType === "") {
    errors.enquiryType = lang === 'hi' 
      ? "कृपया पूछताछ की श्रेणी चुनें।" 
      : "Please select an enquiry category.";
  }

  // Message validation
  if (!formData.message || formData.message.trim().length < 5) {
    errors.message = lang === 'hi' 
      ? "कृपया अपने माल या परिवहन के बारे में कुछ विवरण लिखें (कम से कम 5 अक्षर)।" 
      : "Please describe your cargo or question (at least 5 characters).";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function buildWhatsAppUrl(phoneNumber, customMessage) {
  const cleanPhone = phoneNumber.replace(/[^0-9]/g, "");
  // Prefix with 91 if not present
  const fullPhone = cleanPhone.startsWith("91") ? cleanPhone : `91${cleanPhone}`;
  return `https://wa.me/${fullPhone}?text=${encodeURIComponent(customMessage)}`;
}
