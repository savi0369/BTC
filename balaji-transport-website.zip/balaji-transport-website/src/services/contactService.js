/**
 * Contact & Booking Enquiry Service
 * Handles submission logic and isolates frontend components from network logic.
 */

import { apiClient, isBackendConfigured } from "./api.js";

export async function submitContactEnquiry(enquiryData) {
  // Check if real backend is configured
  if (isBackendConfigured()) {
    return await apiClient("/enquiries", {
      method: "POST",
      data: {
        ...enquiryData,
        submittedAt: new Date().toISOString(),
        source: "website_contact_form"
      }
    });
  }

  // Client-only state: Explain backend integration is pending
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        isSimulated: true,
        message: "Client-side validation passed. Connect to backend to store enquiry.",
        data: enquiryData
      });
    }, 600);
  });
}
