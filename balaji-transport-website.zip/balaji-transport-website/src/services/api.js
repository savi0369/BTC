/**
 * Base API Client Configuration
 * Supports future Node.js/Express backend integration without rewriting frontend components.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

export const isBackendConfigured = () => Boolean(API_BASE_URL && API_BASE_URL.trim() !== "");

export async function apiClient(endpoint, { data, method = "GET", headers = {} } = {}) {
  if (!isBackendConfigured()) {
    console.info(`[API Service] Client-only mode active. Request to '${endpoint}' simulated.`);
    return {
      status: "mock",
      message: "Backend API is not yet connected. Configure VITE_API_BASE_URL in .env."
    };
  }

  const url = `${API_BASE_URL.replace(/\/$/, "")}/${endpoint.replace(/^\//, "")}`;
  const config = {
    method,
    headers: {
      "Content-Type": "application/json",
      ...headers
    }
  };

  if (data) {
    config.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(url, config);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("[API Service Error]:", error);
    throw error;
  }
}
