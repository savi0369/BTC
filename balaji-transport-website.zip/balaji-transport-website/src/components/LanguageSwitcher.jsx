import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Globe } from 'lucide-react';

export default function LanguageSwitcher({ className = '' }) {
  const { language, setLanguage } = useLanguage();

  return (
    <div 
      className={`language-switcher-group ${className}`}
      role="group"
      aria-label="Language selection"
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        padding: '3px',
        borderRadius: 'var(--radius-full)',
        border: '1px solid rgba(255, 255, 255, 0.2)'
      }}
    >
      <span style={{ padding: '0 6px', color: '#cbd5e1', display: 'flex', alignItems: 'center' }}>
        <Globe size={15} aria-hidden="true" />
      </span>
      <button
        type="button"
        onClick={() => setLanguage('hi')}
        aria-pressed={language === 'hi'}
        style={{
          padding: '4px 10px',
          fontSize: '0.8125rem',
          fontWeight: language === 'hi' ? '700' : '500',
          borderRadius: 'var(--radius-full)',
          backgroundColor: language === 'hi' ? 'var(--color-accent)' : 'transparent',
          color: language === 'hi' ? '#ffffff' : '#e2e8f0',
          transition: 'all var(--transition-fast)'
        }}
      >
        हिन्दी
      </button>
      <button
        type="button"
        onClick={() => setLanguage('en')}
        aria-pressed={language === 'en'}
        style={{
          padding: '4px 10px',
          fontSize: '0.8125rem',
          fontWeight: language === 'en' ? '700' : '500',
          borderRadius: 'var(--radius-full)',
          backgroundColor: language === 'en' ? 'var(--color-accent)' : 'transparent',
          color: language === 'en' ? '#ffffff' : '#e2e8f0',
          transition: 'all var(--transition-fast)'
        }}
      >
        English
      </button>
    </div>
  );
}
