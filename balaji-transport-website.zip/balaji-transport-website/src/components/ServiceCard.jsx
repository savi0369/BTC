import React from 'react';
import { Truck, HelpCircle, Navigation } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import WhatsAppButton from './WhatsAppButton';

export default function ServiceCard({ service }) {
  const { language, t } = useLanguage();

  const getIcon = (iconName) => {
    switch (iconName) {
      case 'Truck':
        return <Truck size={28} color="var(--color-accent)" />;
      case 'HelpCircle':
        return <HelpCircle size={28} color="var(--color-accent)" />;
      case 'Route':
      default:
        return <Navigation size={28} color="var(--color-accent)" />;
    }
  };

  const title = service.title[language] || service.title.en;
  const description = service.description[language] || service.description.en;
  
  // Custom prefilled inquiry message for this specific service
  const serviceEnquiryMsg = language === 'hi'
    ? `नमस्ते बालाजी ट्रांसपोर्ट कंपनी, मैं '${title}' सेवा के संबंध में पूछताछ करना चाहता हूँ। कृपया विवरण प्रदान करें।`
    : `Hello Balaji Transport Company, I would like to enquire about '${title}'. Please contact me with the details.`;

  return (
    <div 
      className="card-base"
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        height: '100%',
        backgroundColor: '#ffffff',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius-lg)'
      }}
    >
      <div>
        <div 
          style={{
            width: '56px',
            height: '56px',
            borderRadius: 'var(--radius-md)',
            backgroundColor: 'rgba(249, 115, 22, 0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: '1.25rem'
          }}
        >
          {getIcon(service.icon)}
        </div>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary)', marginBottom: '0.75rem' }}>
          {title}
        </h3>
        <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.65', marginBottom: '1.5rem' }}>
          {description}
        </p>
      </div>

      <div style={{ paddingTop: '1rem', borderTop: '1px solid var(--color-bg-subtle)' }}>
        <WhatsAppButton 
          message={serviceEnquiryMsg} 
          label={t('services.serviceCardCta')} 
          variant="solid"
          size="sm"
          className="w-full"
        />
      </div>
    </div>
  );
}
