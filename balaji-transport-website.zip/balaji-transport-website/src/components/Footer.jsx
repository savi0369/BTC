import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Truck, ExternalLink, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';

export default function Footer() {
  const { language, t } = useLanguage();
  const { contact } = BUSINESS_INFO;

  return (
    <footer 
      style={{
        backgroundColor: 'var(--color-primary-dark)',
        color: '#cbd5e1',
        paddingTop: '3.5rem',
        paddingBottom: '2rem',
        borderTop: '3px solid var(--color-accent)'
      }}
    >
      <div className="container">
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: '2.5rem',
            marginBottom: '3rem'
          }}
        >
          {/* Column 1: Company Profile */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '1rem' }}>
              <div 
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: 'var(--radius-md)',
                  backgroundColor: 'var(--color-accent)',
                  color: '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Truck size={20} />
              </div>
              <span style={{ color: '#ffffff', fontWeight: 800, fontSize: '1.2rem' }}>
                {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}
              </span>
            </div>
            <p style={{ fontSize: '0.9375rem', lineHeight: '1.65', color: '#94a3b8', marginBottom: '1.25rem' }}>
              {t('footer.aboutSummary')}
            </p>
            <div 
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                padding: '0.5rem 0.75rem',
                borderRadius: 'var(--radius-sm)',
                fontSize: '0.8125rem',
                color: '#cbd5e1'
              }}
            >
              <ShieldCheck size={16} color="var(--color-whatsapp)" />
              <span>{t('footer.verifiedInfoNotice')}</span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 style={{ color: '#ffffff', fontSize: '1.0625rem', fontWeight: 700, marginBottom: '1.25rem' }}>
              {t('footer.quickLinksTitle')}
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.625rem', padding: 0 }}>
              <li>
                <Link to="/" style={{ color: '#94a3b8', transition: 'color var(--transition-fast)' }} onMouseEnter={e => e.target.style.color='#f97316'} onMouseLeave={e => e.target.style.color='#94a3b8'}>
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/about" style={{ color: '#94a3b8', transition: 'color var(--transition-fast)' }} onMouseEnter={e => e.target.style.color='#f97316'} onMouseLeave={e => e.target.style.color='#94a3b8'}>
                  {t('nav.about')}
                </Link>
              </li>
              <li>
                <Link to="/services" style={{ color: '#94a3b8', transition: 'color var(--transition-fast)' }} onMouseEnter={e => e.target.style.color='#f97316'} onMouseLeave={e => e.target.style.color='#94a3b8'}>
                  {t('nav.services')}
                </Link>
              </li>
              <li>
                <Link to="/documents" style={{ color: '#94a3b8', transition: 'color var(--transition-fast)' }} onMouseEnter={e => e.target.style.color='#f97316'} onMouseLeave={e => e.target.style.color='#94a3b8'}>
                  {t('nav.documents')}
                </Link>
              </li>
              <li>
                <Link to="/contact" style={{ color: '#94a3b8', transition: 'color var(--transition-fast)' }} onMouseEnter={e => e.target.style.color='#f97316'} onMouseLeave={e => e.target.style.color='#94a3b8'}>
                  {t('nav.contact')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Verified Contact Info */}
          <div>
            <h4 style={{ color: '#ffffff', fontSize: '1.0625rem', fontWeight: 700, marginBottom: '1.25rem' }}>
              {t('footer.contactTitle')}
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem', fontSize: '0.9375rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.625rem' }}>
                <Phone size={18} color="var(--color-accent)" style={{ flexShrink: 0, marginTop: '3px' }} />
                <div>
                  <a href={contact.phones[0].tel} style={{ color: '#ffffff', fontWeight: 600, display: 'block' }}>
                    +91 {contact.phones[0].display}
                  </a>
                  <a href={contact.phones[1].tel} style={{ color: '#ffffff', fontWeight: 600, display: 'block' }}>
                    +91 {contact.phones[1].display}
                  </a>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
                <Mail size={18} color="var(--color-accent)" style={{ flexShrink: 0 }} />
                <a href={`mailto:${contact.email}`} style={{ color: '#cbd5e1' }}>
                  {contact.email}
                </a>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.625rem' }}>
                <MapPin size={18} color="var(--color-accent)" style={{ flexShrink: 0, marginTop: '3px' }} />
                <span>
                  {contact.address[language] || contact.address.en}
                </span>
              </div>

              <div style={{ marginTop: '0.25rem' }}>
                <a
                  href={contact.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.375rem',
                    color: 'var(--color-accent)',
                    fontSize: '0.875rem',
                    fontWeight: 600
                  }}
                >
                  <span>{t('contact.googleMapsButton')}</span>
                  <ExternalLink size={14} />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div 
          style={{
            paddingTop: '1.75rem',
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '1rem',
            fontSize: '0.875rem',
            color: '#94a3b8'
          }}
        >
          <div>
            © {new Date().getFullYear()} {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}. {t('footer.copyright')}
          </div>
          <div>
            CEO: {BUSINESS_INFO.ceo.name} | Mehdawel, Sant Kabir Nagar (UP)
          </div>
        </div>
      </div>
    </footer>
  );
}
