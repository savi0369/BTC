import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, ArrowRight } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import WhatsAppButton from './WhatsAppButton';

export default function ContactCTA() {
  const { t } = useLanguage();
  const phone = BUSINESS_INFO.contact.phones[0];

  return (
    <section 
      style={{
        backgroundColor: 'var(--color-primary)',
        color: '#ffffff',
        padding: '4rem 1.25rem',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div 
        style={{
          position: 'absolute',
          top: '-50px',
          right: '-50px',
          width: '240px',
          height: '240px',
          borderRadius: '50%',
          backgroundColor: 'rgba(249, 115, 22, 0.08)',
          pointerEvents: 'none'
        }}
      />
      <div className="container" style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.25rem', fontWeight: 800, marginBottom: '1rem', color: '#ffffff' }}>
          {t('home.ctaTitle')}
        </h2>
        <p style={{ maxWidth: '640px', margin: '0 auto 2.25rem auto', color: '#cbd5e1', fontSize: '1.125rem' }}>
          {t('home.ctaSubtitle')}
        </p>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center', alignItems: 'center' }}>
          <a
            href={phone.tel}
            className="btn btn-primary"
            style={{ fontSize: '1rem', padding: '0.875rem 1.75rem' }}
          >
            <Phone size={18} />
            <span>{t('hero.ctaCall')}: {phone.display}</span>
          </a>

          <WhatsAppButton size="lg" />

          <Link
            to="/contact"
            className="btn btn-outline"
            style={{ 
              fontSize: '1rem', 
              padding: '0.875rem 1.75rem', 
              backgroundColor: 'transparent',
              borderColor: 'rgba(255,255,255,0.4)',
              color: '#ffffff'
            }}
          >
            <span>{t('home.ctaButton')}</span>
            <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </section>
  );
}
