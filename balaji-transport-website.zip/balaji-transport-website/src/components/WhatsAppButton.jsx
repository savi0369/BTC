import React from 'react';
import { MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../config/business';
import { buildWhatsAppUrl } from '../utils/validation';
import { useLanguage } from '../context/LanguageContext';

export default function WhatsAppButton({ 
  phoneNumber = BUSINESS_INFO.contact.phones[0].whatsapp,
  message,
  label,
  variant = "solid", // solid, outline, floating
  size = "md",
  className = ""
}) {
  const { language, t } = useLanguage();
  const defaultMsg = BUSINESS_INFO.sampleEnquiryMessage[language] || BUSINESS_INFO.sampleEnquiryMessage.en;
  const targetMsg = message || defaultMsg;
  const buttonLabel = label || t('nav.whatsappEnquiry');
  const url = buildWhatsAppUrl(phoneNumber, targetMsg);

  if (variant === "floating") {
    return (
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          zIndex: 999,
          backgroundColor: 'var(--color-whatsapp)',
          color: '#ffffff',
          width: '56px',
          height: '56px',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 14px rgba(37, 211, 102, 0.45)',
          transition: 'transform var(--transition-normal), box-shadow var(--transition-normal)'
        }}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.08)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
      >
        <MessageCircle size={28} />
      </a>
    );
  }

  const isSolid = variant === "solid";

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={`btn ${isSolid ? 'btn-whatsapp' : 'btn-outline'} ${className}`}
      style={{
        padding: size === 'sm' ? '0.5rem 1rem' : size === 'lg' ? '0.875rem 1.75rem' : '0.75rem 1.5rem',
        fontSize: size === 'sm' ? '0.875rem' : size === 'lg' ? '1.0625rem' : '0.9375rem',
        textDecoration: 'none',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.5rem'
      }}
    >
      <MessageCircle size={size === 'sm' ? 16 : 18} />
      <span>{buttonLabel}</span>
    </a>
  );
}
