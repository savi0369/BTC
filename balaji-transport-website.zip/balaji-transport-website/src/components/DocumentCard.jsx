import React from 'react';
import { FileText, Download, ExternalLink, ShieldAlert } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function DocumentCard({ doc }) {
  const { language, t } = useLanguage();
  const title = doc.title[language] || doc.title.en;
  const description = doc.description[language] || doc.description.en;
  const docUrl = `/documents/${doc.fileName}`;

  return (
    <div 
      className="card-base"
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        backgroundColor: '#ffffff'
      }}
    >
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
          <div 
            style={{
              padding: '10px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'rgba(15, 39, 68, 0.08)',
              color: 'var(--color-primary)'
            }}
          >
            <FileText size={24} />
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
              {doc.fileSize || 'PDF DOCUMENT'}
            </span>
            <h4 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
              {title}
            </h4>
          </div>
        </div>

        <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>
          {description}
        </p>
      </div>

      <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
        {doc.isAvailable ? (
          <>
            <a
              href={docUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-navy"
              style={{ flex: 1, padding: '0.625rem 1rem', fontSize: '0.875rem' }}
            >
              <ExternalLink size={16} />
              <span>{t('documents.viewPdf')}</span>
            </a>
            <a
              href={docUrl}
              download={doc.fileName}
              className="btn btn-primary"
              style={{ flex: 1, padding: '0.625rem 1rem', fontSize: '0.875rem' }}
            >
              <Download size={16} />
              <span>{t('documents.downloadPdf')}</span>
            </a>
          </>
        ) : (
          <div 
            style={{
              width: '100%',
              padding: '0.75rem',
              borderRadius: 'var(--radius-sm)',
              backgroundColor: 'var(--color-warning-bg)',
              border: '1px solid #fde68a',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              color: 'var(--color-warning)',
              fontSize: '0.8125rem'
            }}
          >
            <ShieldAlert size={16} flexShrink={0} />
            <span>Document verification pending administrative upload</span>
          </div>
        )}
      </div>
    </div>
  );
}
