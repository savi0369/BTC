import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Phone, Menu, X, Truck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import LanguageSwitcher from './LanguageSwitcher';

export default function Header() {
  const { language, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { path: '/', label: t('nav.home') },
    { path: '/about', label: t('nav.about') },
    { path: '/services', label: t('nav.services') },
    { path: '/documents', label: t('nav.documents') },
    { path: '/contact', label: t('nav.contact') }
  ];

  const primaryPhone = BUSINESS_INFO.contact.phones[0];

  return (
    <header 
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        backgroundColor: 'var(--color-primary)',
        boxShadow: '0 2px 8px rgba(15, 39, 68, 0.25)',
        borderBottom: '2px solid var(--color-accent)'
      }}
    >
      <div className="container">
        <div 
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: '74px'
          }}
        >
          {/* Logo / Brand Name */}
          <Link 
            to="/" 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '0.75rem', 
              textDecoration: 'none' 
            }}
            aria-label="Balaji Transport Company Home"
          >
            <div 
              style={{
                width: '42px',
                height: '42px',
                borderRadius: 'var(--radius-md)',
                backgroundColor: 'var(--color-accent)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 2px 6px rgba(249, 115, 22, 0.4)'
              }}
            >
              <Truck size={24} />
            </div>
            <div>
              <div style={{ color: '#ffffff', fontWeight: 800, fontSize: '1.25rem', letterSpacing: '-0.01em', lineHeight: '1.15' }}>
                {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}
              </div>
              <div style={{ color: '#94a3b8', fontSize: '0.75rem', letterSpacing: '0.02em', fontWeight: 500 }}>
                {language === 'hi' ? 'मेंहदावल, संत कबीर नगर' : 'Mehdawel, Sant Kabir Nagar (UP)'}
              </div>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav 
            className="desktop-nav"
            style={{
              display: 'none',
              alignItems: 'center',
              gap: '1.5rem'
            }}
          >
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                style={({ isActive }) => ({
                  color: isActive ? 'var(--color-accent)' : '#e2e8f0',
                  fontWeight: isActive ? '700' : '500',
                  fontSize: '0.9375rem',
                  padding: '0.5rem 0.25rem',
                  borderBottom: isActive ? '2px solid var(--color-accent)' : '2px solid transparent',
                  transition: 'color var(--transition-fast)'
                })}
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          {/* Right Header Actions: Language Switcher & Call Button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
            <LanguageSwitcher />

            <a
              href={primaryPhone.tel}
              className="btn btn-primary header-call-btn"
              style={{
                display: 'none',
                padding: '0.5rem 1rem',
                fontSize: '0.875rem'
              }}
            >
              <Phone size={15} />
              <span>{t('nav.callNow')}</span>
            </a>

            {/* Mobile Hamburger Toggle Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? t('nav.menuClose') : t('nav.menuOpen')}
              className="mobile-menu-toggle"
              style={{
                color: '#ffffff',
                padding: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              {mobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div 
          style={{
            backgroundColor: 'var(--color-primary-dark)',
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            padding: '1.25rem var(--container-padding) 1.5rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.75rem'
          }}
        >
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              onClick={() => setMobileMenuOpen(false)}
              style={({ isActive }) => ({
                color: isActive ? 'var(--color-accent)' : '#ffffff',
                fontWeight: isActive ? '700' : '500',
                fontSize: '1rem',
                padding: '0.75rem 0.5rem',
                borderLeft: isActive ? '3px solid var(--color-accent)' : '3px solid transparent',
                backgroundColor: isActive ? 'rgba(255, 255, 255, 0.05)' : 'transparent',
                borderRadius: 'var(--radius-sm)'
              })}
            >
              {link.label}
            </NavLink>
          ))}

          <div style={{ marginTop: '0.75rem', paddingTop: '1rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
            <a
              href={primaryPhone.tel}
              className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              <Phone size={16} />
              <span>{t('nav.callNow')}: {primaryPhone.display}</span>
            </a>
          </div>
        </div>
      )}

      {/* Embedded Responsive Media Query Helper */}
      <style>{`
        @media (min-width: 900px) {
          .desktop-nav {
            display: flex !important;
          }
          .header-call-btn {
            display: inline-flex !important;
          }
          .mobile-menu-toggle {
            display: none !important;
          }
        }
      `}</style>
    </header>
  );
}
