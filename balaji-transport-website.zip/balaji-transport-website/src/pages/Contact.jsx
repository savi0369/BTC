import React, { useState } from 'react';
import { Phone, Mail, MapPin, ExternalLink, Send, AlertCircle, CheckCircle, Info } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import { validateContactForm, buildWhatsAppUrl } from '../utils/validation';
import { submitContactEnquiry } from '../services/contactService';
import WhatsAppButton from '../components/WhatsAppButton';

export default function Contact() {
  const { language, t } = useLanguage();
  const { contact } = BUSINESS_INFO;

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    enquiryType: '',
    message: ''
  });

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    // Clear validation error on type
    if (formErrors[name]) {
      setFormErrors((prev) => ({
        ...prev,
        [name]: null
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validation = validateContactForm(formData, language);
    if (!validation.isValid) {
      setFormErrors(validation.errors);
      return;
    }

    setIsSubmitting(true);
    setFormErrors({});

    try {
      await submitContactEnquiry(formData);
      setSubmissionSuccess(true);
    } catch (err) {
      console.error('Submission error:', err);
      setFormErrors({
        form: language === 'hi' 
          ? 'फॉर्म सबमिट करने में समस्या आई। कृपया सीधे फोन या व्हाट्सएप करें।' 
          : 'Could not process form. Please call or message directly.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // WhatsApp prefilled message containing submitted form info
  const generateSubmittedWhatsAppUrl = () => {
    const enquiryCategoryText = formData.enquiryType || 'General Enquiry';
    const msg = language === 'hi'
      ? `नमस्ते बालाजी ट्रांसपोर्ट कंपनी,\nनाम: ${formData.name}\nमोबाइल: ${formData.phone}\nपूछताछ प्रकार: ${enquiryCategoryText}\nविवरण: ${formData.message}`
      : `Hello Balaji Transport Company,\nName: ${formData.name}\nPhone: ${formData.phone}\nCategory: ${enquiryCategoryText}\nDetails: ${formData.message}`;
    return buildWhatsAppUrl(contact.phones[0].whatsapp, msg);
  };

  return (
    <div>
      {/* Page Header */}
      <section style={{ backgroundColor: 'var(--color-primary)', color: '#ffffff', padding: '3.5rem 1.25rem' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('contact.pageTitle')}
          </h1>
          <p style={{ maxWidth: '680px', margin: '0 auto', color: '#cbd5e1', fontSize: '1.125rem' }}>
            {t('contact.pageSubtitle')}
          </p>
        </div>
      </section>

      {/* Main Content: Info & Form */}
      <section className="section-py" style={{ backgroundColor: 'var(--color-bg-base)' }}>
        <div className="container">
          <div 
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
              gap: '2.5rem',
              alignItems: 'start'
            }}
          >
            {/* Left Column: Direct Contact Details */}
            <div>
              <span className="section-tag">{t('contact.quickContactTitle')}</span>
              <h2 style={{ fontSize: '1.875rem', fontWeight: 800, color: 'var(--color-primary)', marginBottom: '1.5rem' }}>
                {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}
              </h2>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', marginBottom: '2rem' }}>
                {/* Phone 1 */}
                <div className="card-base" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ padding: '10px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(249, 115, 22, 0.1)', color: 'var(--color-accent)' }}>
                    <Phone size={22} />
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
                      {t('contact.phone1Title')}
                    </div>
                    <a href={contact.phones[0].tel} style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                      +91 {contact.phones[0].display}
                    </a>
                  </div>
                </div>

                {/* Phone 2 */}
                <div className="card-base" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ padding: '10px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(249, 115, 22, 0.1)', color: 'var(--color-accent)' }}>
                    <Phone size={22} />
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
                      {t('contact.phone2Title')}
                    </div>
                    <a href={contact.phones[1].tel} style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                      +91 {contact.phones[1].display}
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="card-base" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ padding: '10px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(15, 39, 68, 0.08)', color: 'var(--color-primary)' }}>
                    <Mail size={22} />
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
                      {t('contact.emailTitle')}
                    </div>
                    <a href={`mailto:${contact.email}`} style={{ fontSize: '0.9375rem', fontWeight: 600, color: 'var(--color-primary)' }}>
                      {contact.email}
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div className="card-base" style={{ padding: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem', marginBottom: '1rem' }}>
                    <div style={{ padding: '10px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(15, 39, 68, 0.08)', color: 'var(--color-primary)' }}>
                      <MapPin size={22} />
                    </div>
                    <div>
                      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
                        {t('contact.addressTitle')}
                      </div>
                      <div style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--color-primary)', marginTop: '2px' }}>
                        {contact.address[language] || contact.address.en}
                      </div>
                    </div>
                  </div>

                  {/* Google Maps Search Link */}
                  <a
                    href={contact.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-navy"
                    style={{ width: '100%', fontSize: '0.875rem', padding: '0.625rem 1rem' }}
                  >
                    <span>{t('contact.googleMapsButton')}</span>
                    <ExternalLink size={15} />
                  </a>
                </div>
              </div>

              {/* Instant WhatsApp Help */}
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <WhatsAppButton phoneNumber={contact.phones[0].whatsapp} size="md" />
                <WhatsAppButton phoneNumber={contact.phones[1].whatsapp} size="md" label="WhatsApp 2" />
              </div>
            </div>

            {/* Right Column: Contact Form */}
            <div 
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: 'clamp(1.5rem, 4vw, 2.5rem)',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <h3 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--color-primary)', marginBottom: '0.5rem' }}>
                {t('contact.formTitle')}
              </h3>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', marginBottom: '1.5rem' }}>
                {t('contact.formSubtitle')}
              </p>

              {/* Important Demonstration Notice */}
              <div 
                style={{
                  backgroundColor: 'var(--color-bg-base)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-md)',
                  padding: '1rem',
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.75rem',
                  marginBottom: '1.75rem'
                }}
              >
                <Info size={18} color="var(--color-accent)" style={{ flexShrink: 0, marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                    {t('contact.noticeBoxTitle')}
                  </div>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', lineHeight: '1.5' }}>
                    {t('contact.noticeBoxText')}
                  </div>
                </div>
              </div>

              {submissionSuccess ? (
                /* Success State with WhatsApp Forward Option */
                <div 
                  style={{
                    backgroundColor: 'var(--color-success-bg)',
                    border: '1px solid #bbf7d0',
                    borderRadius: 'var(--radius-md)',
                    padding: '1.5rem',
                    textAlign: 'center'
                  }}
                >
                  <CheckCircle size={40} color="var(--color-success)" style={{ margin: '0 auto 0.75rem auto' }} />
                  <h4 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-success)', marginBottom: '0.5rem' }}>
                    {t('contact.successTitle')}
                  </h4>
                  <p style={{ fontSize: '0.9375rem', color: '#166534', marginBottom: '1.5rem', lineHeight: '1.6' }}>
                    {t('contact.successMessage')}
                  </p>

                  <a
                    href={generateSubmittedWhatsAppUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-whatsapp"
                    style={{ width: '100%', padding: '0.875rem' }}
                  >
                    <span>Send Verified Enquiry via WhatsApp</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      setSubmissionSuccess(false);
                      setFormData({ name: '', phone: '', enquiryType: '', message: '' });
                    }}
                    style={{ marginTop: '1rem', fontSize: '0.8125rem', color: 'var(--color-text-muted)', textDecoration: 'underline' }}
                  >
                    Send another enquiry
                  </button>
                </div>
              ) : (
                /* Standard Contact Form */
                <form onSubmit={handleSubmit} noValidate>
                  {/* Name Field */}
                  <div style={{ marginBottom: '1.25rem' }}>
                    <label 
                      htmlFor="contact-name"
                      style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '0.375rem' }}
                    >
                      {t('contact.nameLabel')} <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder={t('contact.namePlaceholder')}
                      style={{
                        width: '100%',
                        padding: '0.75rem 1rem',
                        fontSize: '0.9375rem',
                        border: `1.5px solid ${formErrors.name ? 'var(--color-error)' : 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-md)',
                        outline: 'none',
                        backgroundColor: '#ffffff'
                      }}
                    />
                    {formErrors.name && (
                      <div style={{ color: 'var(--color-error)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
                        {formErrors.name}
                      </div>
                    )}
                  </div>

                  {/* Phone Field */}
                  <div style={{ marginBottom: '1.25rem' }}>
                    <label 
                      htmlFor="contact-phone"
                      style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '0.375rem' }}
                    >
                      {t('contact.phoneLabel')} <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder={t('contact.phonePlaceholder')}
                      maxLength={10}
                      style={{
                        width: '100%',
                        padding: '0.75rem 1rem',
                        fontSize: '0.9375rem',
                        border: `1.5px solid ${formErrors.phone ? 'var(--color-error)' : 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-md)',
                        outline: 'none',
                        backgroundColor: '#ffffff'
                      }}
                    />
                    {formErrors.phone && (
                      <div style={{ color: 'var(--color-error)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
                        {formErrors.phone}
                      </div>
                    )}
                  </div>

                  {/* Enquiry Category */}
                  <div style={{ marginBottom: '1.25rem' }}>
                    <label 
                      htmlFor="contact-enquiryType"
                      style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '0.375rem' }}
                    >
                      {t('contact.enquiryTypeLabel')} <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <select
                      id="contact-enquiryType"
                      name="enquiryType"
                      value={formData.enquiryType}
                      onChange={handleInputChange}
                      style={{
                        width: '100%',
                        padding: '0.75rem 1rem',
                        fontSize: '0.9375rem',
                        border: `1.5px solid ${formErrors.enquiryType ? 'var(--color-error)' : 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-md)',
                        outline: 'none',
                        backgroundColor: '#ffffff'
                      }}
                    >
                      <option value="">{t('contact.enquiryOptions.select')}</option>
                      <option value="All-India Goods Booking">{t('contact.enquiryOptions.allIndia')}</option>
                      <option value="Mumbai/Bhiwandi to Mehdawel">{t('contact.enquiryOptions.mumbaiMehdawel')}</option>
                      <option value="Freight Rate Estimate">{t('contact.enquiryOptions.freightRate')}</option>
                      <option value="General Consultation">{t('contact.enquiryOptions.general')}</option>
                    </select>
                    {formErrors.enquiryType && (
                      <div style={{ color: 'var(--color-error)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
                        {formErrors.enquiryType}
                      </div>
                    )}
                  </div>

                  {/* Message Field */}
                  <div style={{ marginBottom: '1.5rem' }}>
                    <label 
                      htmlFor="contact-message"
                      style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '0.375rem' }}
                    >
                      {t('contact.messageLabel')} <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <textarea
                      id="contact-message"
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder={t('contact.messagePlaceholder')}
                      style={{
                        width: '100%',
                        padding: '0.75rem 1rem',
                        fontSize: '0.9375rem',
                        border: `1.5px solid ${formErrors.message ? 'var(--color-error)' : 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-md)',
                        outline: 'none',
                        backgroundColor: '#ffffff',
                        resize: 'vertical'
                      }}
                    />
                    {formErrors.message && (
                      <div style={{ color: 'var(--color-error)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
                        {formErrors.message}
                      </div>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="btn btn-primary"
                    style={{ width: '100%', padding: '0.875rem' }}
                  >
                    <Send size={18} />
                    <span>{isSubmitting ? t('contact.submittingButton') : t('contact.submitButton')}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
