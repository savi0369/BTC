import React from 'react';
import { FileText, FolderPlus, Info } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { DOCUMENTS_CONFIG } from '../config/documents';
import DocumentCard from '../components/DocumentCard';
import ContactCTA from '../components/ContactCTA';

export default function Documents() {
  const { t } = useLanguage();
  const availableDocs = DOCUMENTS_CONFIG.filter(doc => doc.isAvailable);

  return (
    <div>
      {/* Page Header */}
      <section style={{ backgroundColor: 'var(--color-primary)', color: '#ffffff', padding: '3.5rem 1.25rem' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('documents.pageTitle')}
          </h1>
          <p style={{ maxWidth: '680px', margin: '0 auto', color: '#cbd5e1', fontSize: '1.125rem' }}>
            {t('documents.pageSubtitle')}
          </p>
        </div>
      </section>

      {/* Document Library Section */}
      <section className="section-py" style={{ backgroundColor: 'var(--color-bg-base)' }}>
        <div className="container">
          {availableDocs.length > 0 ? (
            <div 
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                gap: '2rem',
                marginBottom: '3rem'
              }}
            >
              {availableDocs.map((doc) => (
                <DocumentCard key={doc.id} doc={doc} />
              ))}
            </div>
          ) : (
            /* Empty State Container */
            <div 
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: 'clamp(2rem, 5vw, 4rem)',
                textAlign: 'center',
                maxWidth: '680px',
                margin: '0 auto 3rem auto',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div 
                style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  backgroundColor: 'rgba(15, 39, 68, 0.08)',
                  color: 'var(--color-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem auto'
                }}
              >
                <FileText size={32} />
              </div>
              <h3 style={{ fontSize: '1.375rem', fontWeight: 700, color: 'var(--color-primary)', marginBottom: '0.75rem' }}>
                {t('documents.emptyStateTitle')}
              </h3>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.7' }}>
                {t('documents.emptyStateDesc')}
              </p>
            </div>
          )}

          {/* Admin Guide Box: How to add verified PDFs */}
          <div 
            style={{
              backgroundColor: '#ffffff',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: '2rem',
              maxWidth: '760px',
              margin: '0 auto'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '1rem', color: 'var(--color-primary)' }}>
              <Info size={20} color="var(--color-accent)" />
              <h4 style={{ fontSize: '1.0625rem', fontWeight: 700 }}>
                {t('documents.howToUploadTitle')}
              </h4>
            </div>

            <ol style={{ paddingLeft: '1.25rem', color: 'var(--color-text-muted)', fontSize: '0.875rem', lineHeight: '1.8' }}>
              <li>{t('documents.howToUploadStep1')}</li>
              <li>{t('documents.howToUploadStep2')}</li>
              <li>{t('documents.howToUploadStep3')}</li>
            </ol>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  );
}
