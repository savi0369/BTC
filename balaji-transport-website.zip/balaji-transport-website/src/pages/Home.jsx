import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, ArrowRight, Route, MapPin, CheckCircle, ShieldCheck, Truck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import WhatsAppButton from '../components/WhatsAppButton';
import ServiceCard from '../components/ServiceCard';
import ContactCTA from '../components/ContactCTA';

export default function Home() {
  const { language, t } = useLanguage();
  const primaryPhone = BUSINESS_INFO.contact.phones[0];
  const { services } = BUSINESS_INFO;

  return (
    <div>
      {/* 1. Hero Section */}
      <section 
        style={{
          position: 'relative',
          minHeight: '580px',
          display: 'flex',
          alignItems: 'center',
          backgroundColor: 'var(--color-primary-dark)',
          color: '#ffffff',
          overflow: 'hidden'
        }}
      >
        {/* Background Image with Dark Contrast Overlay */}
        <div 
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: "url('/images/hero-truck.jpg')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.38
          }}
        />
        <div 
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to right, rgba(9, 23, 40, 0.96) 20%, rgba(15, 39, 68, 0.85) 60%, rgba(15, 39, 68, 0.6) 100%)'
          }}
        />

        <div className="container" style={{ position: 'relative', zIndex: 2, paddingTop: '3.5rem', paddingBottom: '3.5rem' }}>
          <div style={{ maxWidth: '780px' }}>
            {/* Location Tag */}
            <div 
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                backgroundColor: 'rgba(255, 255, 255, 0.12)',
                backdropFilter: 'blur(4px)',
                padding: '0.35rem 0.875rem',
                borderRadius: 'var(--radius-full)',
                fontSize: '0.8125rem',
                fontWeight: 600,
                color: '#fed7aa',
                marginBottom: '1.25rem',
                border: '1px solid rgba(254, 215, 170, 0.3)'
              }}
            >
              <MapPin size={14} color="var(--color-accent)" />
              <span>{t('hero.locationBadge')}</span>
            </div>

            {/* Main Brand Heading */}
            <h1 
              style={{
                fontSize: 'clamp(2.25rem, 5vw, 3.5rem)',
                fontWeight: 800,
                lineHeight: 1.15,
                color: '#ffffff',
                marginBottom: '0.5rem',
                letterSpacing: '-0.02em'
              }}
            >
              {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}
            </h1>

            {/* Prominent Hindi Callout */}
            <div 
              style={{
                fontSize: 'clamp(1.25rem, 2.5vw, 1.75rem)',
                fontWeight: 700,
                color: 'var(--color-accent)',
                marginBottom: '1rem',
                lineHeight: 1.3
              }}
            >
              {t('hero.hindiHeadline')}
            </div>

            {/* English Supporting Text */}
            <p 
              style={{
                fontSize: '1.125rem',
                color: '#e2e8f0',
                marginBottom: '1.75rem',
                lineHeight: 1.6,
                maxWidth: '680px'
              }}
            >
              {t('hero.subheading')}
            </p>

            {/* Known Route Highlight Badge */}
            <div 
              style={{
                backgroundColor: 'rgba(15, 39, 68, 0.75)',
                border: '1px solid rgba(249, 115, 22, 0.4)',
                borderRadius: 'var(--radius-md)',
                padding: '0.875rem 1.25rem',
                marginBottom: '2rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.875rem'
              }}
            >
              <div 
                style={{
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  backgroundColor: 'var(--color-accent)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                <Route size={20} color="#ffffff" />
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--color-accent)', letterSpacing: '0.05em' }}>
                  {t('hero.routeHighlightTitle')}
                </div>
                <div style={{ fontSize: '0.9375rem', color: '#ffffff', fontWeight: 600 }}>
                  {t('hero.routeHighlightText')}
                </div>
              </div>
            </div>

            {/* Action Buttons: Call and WhatsApp */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center' }}>
              <a 
                href={primaryPhone.tel}
                className="btn btn-primary"
                style={{ fontSize: '1rem', padding: '0.875rem 1.75rem' }}
              >
                <Phone size={18} />
                <span>{t('hero.ctaCall')}: {primaryPhone.display}</span>
              </a>

              <WhatsAppButton size="lg" />
            </div>
          </div>
        </div>
      </section>

      {/* 2. Brief Introduction to Company */}
      <section className="section-py" style={{ backgroundColor: '#ffffff' }}>
        <div className="container">
          <div 
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
              gap: '3rem',
              alignItems: 'center'
            }}
          >
            <div>
              <span className="section-tag">{t('home.aboutSectionTitle')}</span>
              <h2 className="section-title" style={{ textAlign: 'left', marginBottom: '1.25rem' }}>
                {t('home.aboutLead')}
              </h2>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '1rem', lineHeight: '1.75', marginBottom: '1.5rem' }}>
                {t('home.aboutBody')}
              </p>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '2rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', color: 'var(--color-primary)', fontWeight: 600 }}>
                  <CheckCircle size={18} color="var(--color-accent)" />
                  <span>{BUSINESS_INFO.ceo.name} — {BUSINESS_INFO.ceo.role[language] || BUSINESS_INFO.ceo.role.en}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', color: 'var(--color-primary)', fontWeight: 600 }}>
                  <CheckCircle size={18} color="var(--color-accent)" />
                  <span>{BUSINESS_INFO.ceo.experience[language] || BUSINESS_INFO.ceo.experience.en}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', color: 'var(--color-primary)', fontWeight: 600 }}>
                  <CheckCircle size={18} color="var(--color-accent)" />
                  <span>{BUSINESS_INFO.contact.address[language] || BUSINESS_INFO.contact.address.en}</span>
                </div>
              </div>

              <Link to="/about" className="btn btn-navy">
                <span>{t('home.readMore')}</span>
                <ArrowRight size={16} />
              </Link>
            </div>

            <div 
              style={{
                backgroundColor: 'var(--color-bg-base)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '2.25rem',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.25rem' }}>
                <div style={{ padding: '8px', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(15, 39, 68, 0.1)', color: 'var(--color-primary)' }}>
                  <Truck size={24} />
                </div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                  {BUSINESS_INFO.ceo.name}
                </h3>
              </div>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.7', marginBottom: '1.25rem' }}>
                {BUSINESS_INFO.ceo.journeyText[language] || BUSINESS_INFO.ceo.journeyText.en}
              </p>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.7' }}>
                {BUSINESS_INFO.ceo.managementScope[language] || BUSINESS_INFO.ceo.managementScope.en}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Services Overview */}
      <section className="section-py" style={{ backgroundColor: 'var(--color-bg-base)' }}>
        <div className="container">
          <div className="section-header">
            <span className="section-tag">{t('home.servicesSectionTitle')}</span>
            <h2 className="section-title">{t('home.servicesSectionTitle')}</h2>
            <p className="section-subtitle">{t('home.servicesSectionSubtitle')}</p>
          </div>

          <div 
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '2rem'
            }}
          >
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* 4. Featured Route Section */}
      <section className="section-py" style={{ backgroundColor: '#ffffff', borderTop: '1px solid var(--color-border)' }}>
        <div className="container">
          <div 
            style={{
              backgroundColor: 'var(--color-bg-base)',
              border: '2px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: 'clamp(1.5rem, 4vw, 3rem)',
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '2rem',
              alignItems: 'center'
            }}
          >
            <div>
              <span className="section-tag">{t('home.routeSectionTitle')}</span>
              <h2 style={{ fontSize: '1.875rem', fontWeight: 800, color: 'var(--color-primary)', marginBottom: '1rem' }}>
                {t('home.routeSectionSubtitle')}
              </h2>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '1rem', lineHeight: '1.7', marginBottom: '1.5rem' }}>
                {t('home.routeDescription')}
              </p>
              
              <WhatsAppButton 
                message={language === 'hi' 
                  ? "नमस्ते बालाजी ट्रांसपोर्ट कंपनी, मैं मुंबई/भिवंडी से मेंहदावल मार्ग के लिए माल बुकिंग पूछताछ करना चाहता हूँ।"
                  : "Hello Balaji Transport Company, I would like to enquire about goods booking for the Mumbai/Bhiwandi to Mehdawel route."
                }
                label={t('home.enquireRoute')}
                size="md"
              />
            </div>

            <div 
              style={{
                backgroundColor: '#ffffff',
                borderRadius: 'var(--radius-md)',
                padding: '1.75rem',
                border: '1px solid var(--color-border)',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-accent-dark)', textTransform: 'uppercase' }}>
                    {t('home.originLabel')}
                  </div>
                  <div style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                    {t('home.originValue')}
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', color: 'var(--color-accent)' }}>
                  <div style={{ flex: 1, height: '2px', backgroundColor: 'var(--color-border)' }} />
                  <Route size={20} />
                  <div style={{ flex: 1, height: '2px', backgroundColor: 'var(--color-border)' }} />
                </div>

                <div>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-accent-dark)', textTransform: 'uppercase' }}>
                    {t('home.destinationLabel')}
                  </div>
                  <div style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                    {t('home.destinationValue')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Contact CTA Banner */}
      <ContactCTA />
    </div>
  );
}
