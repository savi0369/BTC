import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, Home } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function NotFound() {
  const { t } = useLanguage();

  return (
    <section className="section-py" style={{ minHeight: '60vh', display: 'flex', alignItems: 'center' }}>
      <div className="container" style={{ textAlign: 'center' }}>
        <div 
          style={{
            width: '72px',
            height: '72px',
            borderRadius: '50%',
            backgroundColor: 'var(--color-error-bg)',
            color: 'var(--color-error)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1.5rem auto'
          }}
        >
          <AlertCircle size={40} />
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--color-primary)', marginBottom: '0.5rem' }}>
          404 - {t('notFound.title')}
        </h1>
        <p style={{ color: 'var(--color-text-muted)', fontSize: '1.125rem', marginBottom: '2rem', maxWidth: '500px', margin: '0 auto 2rem auto' }}>
          {t('notFound.subtitle')}
        </p>
        <Link to="/" className="btn btn-primary" style={{ padding: '0.875rem 1.75rem' }}>
          <Home size={18} />
          <span>{t('notFound.button')}</span>
        </Link>
      </div>
    </section>
  );
}
