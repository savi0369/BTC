import React from 'react';
import { Route, CheckCircle, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import ServiceCard from '../components/ServiceCard';
import WhatsAppButton from '../components/WhatsAppButton';
import ContactCTA from '../components/ContactCTA';

export default function Services() {
  const { language, t } = useLanguage();
  const { services } = BUSINESS_INFO;

  return (
    <div>
      {/* Page Header */}
      <section style={{ backgroundColor: 'var(--color-primary)', color: '#ffffff', padding: '3.5rem 1.25rem' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('services.pageTitle')}
          </h1>
          <p style={{ maxWidth: '680px', margin: '0 auto', color: '#cbd5e1', fontSize: '1.125rem' }}>
            {t('services.pageSubtitle')}
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-py" style={{ backgroundColor: 'var(--color-bg-base)' }}>
        <div className="container">
          <div 
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
              gap: '2rem',
              marginBottom: '3.5rem'
            }}
          >
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>

          {/* Operational Scope & Integrity Disclaimer */}
          <div 
            style={{
              backgroundColor: '#ffffff',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: '2rem',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '1.25rem',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <div 
              style={{
                padding: '10px',
                borderRadius: 'var(--radius-md)',
                backgroundColor: 'rgba(37, 211, 102, 0.1)',
                color: 'var(--color-whatsapp-hover)',
                flexShrink: 0
              }}
            >
              <ShieldCheck size={28} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)', marginBottom: '0.5rem' }}>
                {t('services.importantNoticeTitle')}
              </h3>
              <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.65' }}>
                {t('services.importantNoticeText')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Special Focus on Mumbai/Bhiwandi to Mehdawel Route */}
      <section className="section-py" style={{ backgroundColor: '#ffffff', borderTop: '1px solid var(--color-border)' }}>
        <div className="container">
          <div style={{ maxWidth: '820px', margin: '0 auto', textAlign: 'center' }}>
            <span className="section-tag">{t('services.routeCardTitle')}</span>
            <h2 className="section-title">
              {t('services.routeCardSubtitle')}
            </h2>
            <p style={{ color: 'var(--color-text-muted)', fontSize: '1.0625rem', lineHeight: '1.7', marginBottom: '2rem' }}>
              {language === 'hi'
                ? "मुंबई और भिवंडी के औद्योगिक गोदामों से उत्तर प्रदेश के मेंहदावल (संत कबीर नगर) के लिए नियमित माल बुकिंग परामर्श उपलब्ध है। हमारी टीम व्यापारियों और ट्रांसपोर्टरों के बीच पारदर्शी समन्वय सुनिश्चित करती है।"
                : "Regular freight and goods booking consultations connecting the manufacturing and warehousing hubs of Mumbai and Bhiwandi to Mehdawel, Sant Kabir Nagar (Eastern Uttar Pradesh)."}
            </p>

            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <WhatsAppButton 
                message={language === 'hi' 
                  ? "नमस्ते बालाजी ट्रांसपोर्ट कंपनी, मैं मुंबई/भिवंडी से मेंहदावल मार्ग के संबंध में माल बुकिंग परामर्श चाहता हूँ।"
                  : "Hello Balaji Transport Company, I would like to enquire about goods booking for the Mumbai/Bhiwandi to Mehdawel corridor."
                }
                size="lg"
              />
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  );
}
