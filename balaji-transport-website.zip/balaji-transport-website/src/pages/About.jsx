import React from 'react';
import { User, Briefcase, MapPin, Award, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_INFO } from '../config/business';
import ContactCTA from '../components/ContactCTA';

export default function About() {
  const { language, t } = useLanguage();
  const { ceo, representative, contact } = BUSINESS_INFO;

  return (
    <div>
      {/* Page Header */}
      <section style={{ backgroundColor: 'var(--color-primary)', color: '#ffffff', padding: '3.5rem 1.25rem' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('about.pageTitle')}
          </h1>
          <p style={{ maxWidth: '680px', margin: '0 auto', color: '#cbd5e1', fontSize: '1.125rem' }}>
            {t('about.pageSubtitle')}
          </p>
        </div>
      </section>

      {/* Section 1: Company Profile & Location */}
      <section className="section-py" style={{ backgroundColor: '#ffffff' }}>
        <div className="container">
          <div style={{ maxWidth: '840px', margin: '0 auto' }}>
            <span className="section-tag">{t('about.companyOverviewTitle')}</span>
            <h2 className="section-title" style={{ textAlign: 'left', marginBottom: '1.25rem' }}>
              {BUSINESS_INFO.name[language] || BUSINESS_INFO.name.en}
            </h2>
            <p style={{ fontSize: '1.0625rem', lineHeight: '1.75', color: 'var(--color-text-main)', marginBottom: '1.5rem' }}>
              {t('about.companyOverviewText')}
            </p>
            <div 
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.625rem',
                backgroundColor: 'var(--color-bg-base)',
                padding: '0.75rem 1.25rem',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
                fontWeight: 600,
                color: 'var(--color-primary)'
              }}
            >
              <MapPin size={18} color="var(--color-accent)" />
              <span>{contact.address[language] || contact.address.en}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: CEO Profile */}
      <section className="section-py" style={{ backgroundColor: 'var(--color-bg-base)', borderTop: '1px solid var(--color-border)' }}>
        <div className="container">
          <div style={{ maxWidth: '840px', margin: '0 auto' }}>
            <span className="section-tag">{t('about.leadershipTitle')}</span>
            <h2 className="section-title" style={{ textAlign: 'left', marginBottom: '2rem' }}>
              {t('about.ceoHeading')}
            </h2>

            <div 
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: 'clamp(1.5rem, 4vw, 2.5rem)',
                boxShadow: 'var(--shadow-sm)',
                marginBottom: '2.5rem'
              }}
            >
              <div 
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
                  gap: '2rem',
                  alignItems: 'center',
                  marginBottom: '2rem'
                }}
              >
                {/* Designated Photo Frame for Real CEO Photograph */}
                <div 
                  style={{
                    width: '100%',
                    maxWidth: '240px',
                    aspectRatio: '1/1',
                    borderRadius: 'var(--radius-lg)',
                    border: '2px dashed var(--color-border-subtle)',
                    backgroundColor: 'var(--color-bg-base)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '1.5rem',
                    textAlign: 'center',
                    margin: '0 auto'
                  }}
                >
                  <User size={48} color="var(--color-text-muted)" style={{ marginBottom: '0.75rem' }} />
                  <span style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--color-primary)' }}>
                    {ceo.name}
                  </span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                    Photo Frame (Awaiting Official Portrait)
                  </span>
                </div>

                <div>
                  <div style={{ display: 'inline-block', backgroundColor: 'rgba(249, 115, 22, 0.1)', color: 'var(--color-accent-dark)', fontWeight: 700, fontSize: '0.875rem', padding: '0.25rem 0.75rem', borderRadius: 'var(--radius-full)', marginBottom: '0.5rem' }}>
                    {ceo.experience[language] || ceo.experience.en}
                  </div>
                  <h3 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--color-primary)', marginBottom: '0.25rem' }}>
                    {ceo.name}
                  </h3>
                  <div style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--color-text-muted)', marginBottom: '1rem' }}>
                    {ceo.role[language] || ceo.role.en}
                  </div>
                  <p style={{ color: 'var(--color-text-main)', fontSize: '0.9375rem', lineHeight: '1.65' }}>
                    {t('about.journeyP1')}
                  </p>
                </div>
              </div>

              {/* Career Timeline */}
              <div style={{ paddingTop: '1.75rem', borderTop: '1px solid var(--color-border)' }}>
                <h4 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-primary)', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Briefcase size={18} color="var(--color-accent)" />
                  <span>{t('about.careerTimelineTitle')}</span>
                </h4>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {ceo.careerHistory.map((item, idx) => (
                    <div 
                      key={idx}
                      style={{
                        padding: '1rem 1.25rem',
                        backgroundColor: 'var(--color-bg-base)',
                        borderLeft: '4px solid var(--color-accent)',
                        borderRadius: '0 var(--radius-md) var(--radius-md) 0'
                      }}
                    >
                      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '0.5rem' }}>
                        <span style={{ fontWeight: 700, color: 'var(--color-primary)', fontSize: '1rem' }}>
                          {item.company}
                        </span>
                        <span style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--color-accent-dark)', backgroundColor: '#ffffff', padding: '0.2rem 0.6rem', borderRadius: 'var(--radius-full)', border: '1px solid var(--color-border)' }}>
                          {language === 'hi' ? item.periodHi : item.period}
                        </span>
                      </div>
                      <div style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
                        {language === 'hi' ? item.roleHi : item.role}
                        {item.note && (
                          <span style={{ marginLeft: '0.5rem', fontStyle: 'italic', color: 'var(--color-text-light)' }}>
                            ({language === 'hi' ? item.noteHi : item.note})
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <p style={{ color: 'var(--color-text-main)', fontSize: '0.9375rem', lineHeight: '1.7', marginTop: '1.5rem' }}>
                  {t('about.journeyP2')}
                </p>
              </div>
            </div>

            {/* Section 3: Company Representative */}
            <div 
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: 'clamp(1.5rem, 4vw, 2rem)',
                boxShadow: 'var(--shadow-sm)',
                marginBottom: '2.5rem'
              }}
            >
              <div 
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                  gap: '1.75rem',
                  alignItems: 'center'
                }}
              >
                {/* Designated Photo Frame for Company Representative */}
                <div 
                  style={{
                    width: '100%',
                    maxWidth: '180px',
                    aspectRatio: '1/1',
                    borderRadius: 'var(--radius-lg)',
                    border: '2px dashed var(--color-border-subtle)',
                    backgroundColor: 'var(--color-bg-base)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '1rem',
                    textAlign: 'center',
                    margin: '0 auto'
                  }}
                >
                  <User size={40} color="var(--color-text-muted)" style={{ marginBottom: '0.5rem' }} />
                  <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-primary)' }}>
                    Representative
                  </span>
                  <span style={{ fontSize: '0.6875rem', color: 'var(--color-text-muted)' }}>
                    (Portrait Pending)
                  </span>
                </div>

                <div>
                  <span style={{ fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--color-text-muted)', letterSpacing: '0.05em' }}>
                    {t('about.representativeTitle')}
                  </span>
                  <h3 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--color-primary)', marginTop: '0.25rem', marginBottom: '0.5rem' }}>
                    {representative.role[language] || representative.role.en}
                  </h3>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--color-accent-dark)', fontWeight: 600, marginBottom: '0.75rem' }}>
                    {t('about.representativeStatus')}
                  </div>
                  <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9375rem', lineHeight: '1.65' }}>
                    {representative.note[language] || representative.note.en}
                  </p>
                </div>
              </div>
            </div>

            {/* Section 4: Mission & Vision (Explicitly Marked as Proposed Draft for Approval) */}
            <div 
              style={{
                backgroundColor: 'var(--color-warning-bg)',
                border: '1.5px solid #fde68a',
                borderRadius: 'var(--radius-lg)',
                padding: 'clamp(1.25rem, 3vw, 2rem)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '0.75rem' }}>
                <ShieldAlert size={20} color="var(--color-warning)" />
                <h4 style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-warning)' }}>
                  {t('about.governanceNoticeTitle')}
                </h4>
              </div>
              <p style={{ fontSize: '0.875rem', color: '#78350f', marginBottom: '1.25rem' }}>
                {t('about.governanceNoticeSubtitle')}
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem' }}>
                <div style={{ backgroundColor: '#ffffff', padding: '1.25rem', borderRadius: 'var(--radius-md)', border: '1px solid #fed7aa' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.9375rem', color: 'var(--color-primary)', marginBottom: '0.5rem' }}>
                    {t('about.draftMissionTitle')}
                  </div>
                  <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: '1.6' }}>
                    {t('about.draftMissionText')}
                  </p>
                </div>

                <div style={{ backgroundColor: '#ffffff', padding: '1.25rem', borderRadius: 'var(--radius-md)', border: '1px solid #fed7aa' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.9375rem', color: 'var(--color-primary)', marginBottom: '0.5rem' }}>
                    {t('about.draftVisionTitle')}
                  </div>
                  <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: '1.6' }}>
                    {t('about.draftVisionText')}
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  );
}
