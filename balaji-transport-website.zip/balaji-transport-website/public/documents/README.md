# Documents Directory - Balaji Transport Company

Place approved company PDF documents inside this directory (e.g., `company-profile.pdf`, `rate-card.pdf`).

Once a verified PDF is added:
1. Copy the PDF file here: `public/documents/<filename>.pdf`
2. Register the document metadata in `src/config/documents.js`
3. Set `isAvailable: true` in the configuration record.

*Note: Per strict company guidelines, do not create or display unverified or placeholder certificates, GST registrations, or insurance claims until official documents are authorized.*
